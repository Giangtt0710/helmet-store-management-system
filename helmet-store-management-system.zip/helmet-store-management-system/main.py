import tkinter as tk

import methods.CustomerMethods as CustomerMethods
import methods.EmployeeMethods as EmployeeMethods
import methods.ProductMethods as ProductMethods
import methods.UtilityMethods as UtilityMethods
import database
import credits
from tkinter import *
from PIL import ImageTk, Image

global customer_list
global employee_list
global product_list
customer_list = []
employee_list = []
product_list = []


# When app is open, unzip and load all the data
def on_open():
    # Unzip database
    database.unzip_data()
    # Load all customers
    global customer_list
    customer_list = database.load_customer()
    global employee_list
    employee_list = database.load_employee()
    global product_list
    product_list = database.load_product()


# Save and zip all the data then destroy the window
def on_close():
    # Save all data
    global customer_list
    database.save_customer(customer_list)
    global employee_list
    database.save_employee(employee_list)
    global product_list
    database.save_product(product_list)

    # Zip data and close window
    database.zip_data()
    win.destroy()


# Create main window
win = tk.Tk()

# Set the title and icon
win.title("Helmet Store Management System")
icon = PhotoImage(file="images/logo_Helmet.png")

# Start window at fullscreen
width = win.winfo_screenwidth()
height = win.winfo_screenheight()
win.geometry("%dx%d" % (width, height))

# Left Panel
Frame(win, bg="#E97675").place(x=width / 2, y=0, width=width / 2, height=height)
Frame(win, bg="#E97675").place(x=24, y=24, width=width / 2 - 48, height=height - 98)
Frame(win).place(x=26, y=26, width=width / 2 - 52, height=height - 102)
Frame(win).place(x=50, y=50, width=width / 2 - 100, height=height - 150)

# Right Panel
Label(win, text="HELMET STORE", bg="#E97675", fg="white", font=("Inter", 25, 'bold')) \
    .place(x=width / 2, y=height / 2, width=width / 2, height=25)
Label(win, text="MANAGEMENT SYSTEM", bg="#E97675", fg="white", font=("Inter", 25, 'bold')) \
    .place(x=width / 2, y=height / 2 - 100, width=width / 2, height=25)

# Buttons
cus_but = PhotoImage(file="images/Customer_button.png")
customer_button = Button(win, image=cus_but, borderwidth=0,
                         command=lambda: CustomerMethods.cus_press(win, width, height, customer_list))
customer_button.place(x=200, y=height / 2 - 300)

emp_but = PhotoImage(file="images/Employee_button.png")
employee_button = Button(win, image=emp_but, borderwidth=0,
                         command=lambda: EmployeeMethods.emp_press(win, width, height, employee_list))
employee_button.place(x=200, y=height / 2 - 150)

prod_but = PhotoImage(file="images/Products_button.png")
product_button = Button(win, image=prod_but, borderwidth=0,
                        command=lambda: ProductMethods.prod_press(win, width, height, product_list))
product_button.place(x=200, y=height / 2)

cred_but = PhotoImage(file="images/Credits_button.png")
credit_button = Button(win, image=cred_but, borderwidth=0,
                       command=lambda: credits.credits_press(win, width, height))
credit_button.place(x=190, y=height / 2 + 150)


def main():
    on_open()
    win.protocol("WM_DELETE_WINDOW", on_close)
    win.mainloop()


if __name__ == "__main__":
    main()
