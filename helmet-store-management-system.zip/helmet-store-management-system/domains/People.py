class People:
    def __init__(self, id, name, gend, dob):
        self.__id = id
        self.__name = name
        self.__dob = str(dob)
        self.__gend = gend
        self.__phone = ''
        self.__email = ''
    
    # Getters
    def get_id(self):
        return self.__id
    
    def get_name(self):
        return self.__name

    def get_dob(self):
        return self.__dob

    def get_gend(self):
        return self.__gend

    def get_phone(self):
        return self.__phone

    def get_email(self):
        return self.__email

    # Setters
    def set_id(self, id):
        self.__id = id

    def set_name(self, name):
        self.__name = name
    
    def set_dob(self, dob):
        self.__dob = dob
    
    def set_gend(self, gend):
        self.__gend = gend
        
    def set_phone(self, phone):
        self.__phone = phone
        
    def set_email(self, email):
        self.__email = email


# =======================================================


class Employee(People):
    def __init__(self, id, name, gend, dob, salary):
        super().__init__(id, name, gend, dob)
        self.__salary = salary

    # Getters
    def get_salary(self):
        return self.__salary

    # Setters
    def set_salary(self, salary):
        self.__salary = salary


# =======================================================


class Customer(People):
    def __init__(self, id, name, gend, dob):
        super().__init__(id, name, gend, dob)
