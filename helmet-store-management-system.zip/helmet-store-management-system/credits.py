from tkinter import *


def credits_press(window, width, height):
    credit_subwin = Toplevel(window)
    credit_subwin.geometry("%dx%d" % (width, height))

    icon = PhotoImage(file="images/logo_Helmet.png")
    credit_subwin.iconphoto(False, icon)

    credit_subwin.title("Credits")

    Frame(credit_subwin).place(x=0, y=0, width=width, height=height)

    Label(credit_subwin, fg='#242424', text='BI12-137 _ Thái Trường Giang', anchor='w',
          font=("Inter", 20, 'bold')).place(x=100, y=100, width=width - 200, height=50)

    Label(credit_subwin, fg='#242424', text='BI12-192 _ Bạch Ngọc Hưng', anchor='w',
          font=("Inter", 20, 'bold')).place(x=100, y=170, width=width - 200, height=50)

    Label(credit_subwin, fg='#242424', text='BI12-213 _ Đoàn Phú Khoa', anchor='w',
          font=("Inter", 20, 'bold')).place(x=100, y=240, width=width - 200, height=50)

    Label(credit_subwin, fg='#242424', text='BI12-227 _ Lê Đức Kiên', anchor='w',
          font=("Inter", 20, 'bold')).place(x=100, y=310, width=width - 200, height=50)

    Label(credit_subwin, fg='#242424', text='BI12-233 _ Nhữ Tùng Lâm', anchor='w',
          font=("Inter", 20, 'bold')).place(x=100, y=380, width=width - 200, height=50)

    Label(credit_subwin, fg='#242424', text='GROUP 27',
          font=("Inter", 30, 'bold')).place(x=width / 4 * 3 - 100, y=height / 2 - 50, width=200, height=70)
