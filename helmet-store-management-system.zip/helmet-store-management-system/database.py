import pickle
import os
import zipfile


def zip_data():
    with zipfile.ZipFile('helmet_management.dat', 'w', compression=zipfile.ZIP_DEFLATED) as zip:
        zip.write('customers.pkl')
        zip.write('employees.pkl')
        zip.write('products.pkl')
    os.remove('customers.pkl')
    os.remove('employees.pkl')
    os.remove('products.pkl')


def unzip_data():
    if os.path.exists('helmet_management.dat'):
        with zipfile.ZipFile('helmet_management.dat', 'r') as zip:
            zip.extractall()
        os.remove("helmet_management.dat")


# ================================================================


def save_customer(customer_list):
    with open("customers.pkl", "wb") as f:
        pickle.dump(customer_list, f, pickle.HIGHEST_PROTOCOL)
    

def save_employee(employee_list):
    with open("employees.pkl", "wb") as f:
        pickle.dump(employee_list, f, pickle.HIGHEST_PROTOCOL)


def save_product(product_list):
    with open("products.pkl", "wb") as f:
        pickle.dump(product_list, f, pickle.HIGHEST_PROTOCOL)


# ================================================================


def load_customer():
    customer_list = []
    if os.path.exists("customers.pkl"):
        with open("customers.pkl", "rb") as f:
            customer_list = pickle.load(f)

    return customer_list


def load_employee():
    employee_list = []
    if os.path.exists("employees.pkl"):
        with open("employees.pkl", "rb") as f:
            employee_list = pickle.load(f)

    return employee_list


def load_product():
    product_list = []
    if os.path.exists("products.pkl"):
        with open("products.pkl", "rb") as f:
            product_list = pickle.load(f)

    return product_list



