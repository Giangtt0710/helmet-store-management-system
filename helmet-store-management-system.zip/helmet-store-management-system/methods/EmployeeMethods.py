import tkinter as tk

from domains.People import *
import methods.UtilityMethods as utils
from tkinter import *
from tkinter import ttk
from PIL import ImageTk, Image

global selected_employee


# Empty entry boxes and delete warnings
def clear_entry(entry_frame, id_entry, name_entry, gend_entry, dob_entry, phone_entry, email_entry, salary_entry):
    # Delete all warnings
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=4, sticky='w')
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=5, sticky='w')
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=6, sticky='w')

    # Empty entry boxes
    id_entry.delete(0, END)
    name_entry.delete(0, END)
    gend_entry.delete(0, END)
    dob_entry.delete(0, END)
    phone_entry.delete(0, END)
    email_entry.delete(0, END)
    salary_entry.delete(0, END)

    # Set selected_employee to -1
    global selected_employee
    selected_employee = -1


# Create a new customer
def create_employee(employee_list, emp_tree, entry_frame, id_entry, name_entry, gend_entry, dob_entry,
                    phone_entry, email_entry, salary_entry):
    # Create labels
    Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
        column=6, row=0, sticky='w')
    Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
        column=6, row=1, sticky='w')
    Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
        column=6, row=2, sticky='w')
    Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
        column=6, row=3, sticky='w')
    Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
        column=6, row=4, sticky='w')
    Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
        column=6, row=5, sticky='w')

    global employee_id
    id = id_entry.get()
    name = name_entry.get()
    gend = gend_entry.get()
    dob = dob_entry.get()
    phone = phone_entry.get()
    email = email_entry.get()
    salary = salary_entry.get()

    # Count the amount of invalid entries
    invalid_count = 0

    # Validate ID
    if len(id) == 0:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
        Label(entry_frame, fg='crimson', text='ID cannot be empty!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=0, sticky='w')
        invalid_count += 1
    elif utils.invalid_id(id, "E-") == 1:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
        Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=0, sticky='w')
        invalid_count += 1
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')

    # Validate name
    if len(name) == 0:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
        Label(entry_frame, fg='crimson', text='Name cannot be empty!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=1, sticky='w')
        invalid_count += 1
    elif utils.invalid_name(name) == 1:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
        Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=1, sticky='w')
        invalid_count += 1
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')

    # Validate gender
    if len(gend) == 0:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
        Label(entry_frame, fg='crimson', text='Gender cannot be empty!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=2, sticky='w')
        invalid_count += 1
    elif utils.invalid_gend(gend) == 1:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
        Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=2, sticky='w')
        invalid_count += 1
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')

    # Validate birthday
    if len(dob) == 0:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
        Label(entry_frame, fg='crimson', text='Birthday cannot be empty!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=3, sticky='w')
        invalid_count += 1
    elif utils.invalid_dob(dob) == 1:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
        Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=3, sticky='w')
        invalid_count += 1
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')

    # Validate phone:
    if len(phone) != 0 and phone != '_':
        if utils.invalid_phone(phone) == 1:
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=4, sticky='w')
            invalid_count += 1
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=4, sticky='w')

    # Validate email
    if len(email) != 0 and email != '_':
        if utils.invalid_email(email) == 1:
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')). \
                grid(column=6, row=5, sticky='w')
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=5, sticky='w')

    # Validate salary
    if len(salary) == 0:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
        Label(entry_frame, fg='crimson', text='Salary cannot be empty!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=6, sticky='w')
        invalid_count += 1
    elif utils.invalid_salary(salary) == 1:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
        Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=6, sticky='w')
        invalid_count += 1

    # If everything is valid
    if invalid_count == 0:
        # Add to product list
        new_emp = Employee(id, name, gend, dob, salary)
        if len(phone) > 0:
            new_emp.set_phone(phone)
        if len(email) > 0:
            new_emp.set_email(email)
        employee_list.append(new_emp)

        # Display on treeview
        emp_tree.insert(parent='', index='end', text='', iid=id,
                        values=(id, name, gend, dob, salary))

        # Empty entry boxes
        id_entry.delete(0, END)
        name_entry.delete(0, END)
        gend_entry.delete(0, END)
        dob_entry.delete(0, END)
        phone_entry.delete(0, END)
        email_entry.delete(0, END)
        salary_entry.delete(0, END)

        # Delete all Warnings
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=4, sticky='w')
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=5, sticky='w')
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=6, sticky='w')


# Remove a selected employee
def remove_employee(employees_list, emp_tree):
    # If an employee is selected
    if len(emp_tree.selection()) > 0:
        # Get that employee id
        selected_emp = emp_tree.selection()[0]
        emp_id = emp_tree.item(selected_emp, 'values')[0]

        # Search for that employee in the list and delete
        for employee in employees_list:
            if employee.get_id() == emp_id:
                employees_list.remove(employee)
                break

        # Delete that employee from the treeview
        emp_tree.delete(selected_emp)


# Remove all employees
def remove_all_employees(employee_list, emp_tree):
    for employee in emp_tree.get_children():
        emp_tree.delete(employee)
    employee_list.clear()


# Update en employee's info
def update_employee(employee_list, emp_tree, entry_frame, id_entry, name_entry, gend_entry, dob_entry,
                    phone_entry, email_entry, salary_entry):
    global selected_employee
    global emp_id

    selected_employee = emp_tree.selection()[0]
    if selected_employee != -1:
        Label(entry_frame, bg='white', fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=0, sticky='w')
        Label(entry_frame, bg='white', fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=1, sticky='w')
        Label(entry_frame, bg='white', fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=2, sticky='w')
        Label(entry_frame, bg='white', fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=3, sticky='w')
        Label(entry_frame, bg='white', fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=4, sticky='w')
        Label(entry_frame, bg='white', fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=5, sticky='w')
        Label(entry_frame, bg='white', fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=6, sticky='w')

        id = id_entry.get()
        name = name_entry.get()
        gend = gend_entry.get()
        dob = dob_entry.get()
        phone = phone_entry.get()
        email = email_entry.get()
        salary = salary_entry.get()

        # Validation
        invalid_count = 0

        # Validate ID
        if len(id) == 0:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
            Label(entry_frame, fg='crimson', text='ID cannot be empty!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=0, sticky='w')
            invalid_count += 1
        elif utils.invalid_id(id, "E-") == 1:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=0, sticky='w')
            invalid_count += 1
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')

        # Validate name
        if len(name) == 0:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
            Label(entry_frame, fg='crimson', text='Name cannot be empty!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=1, sticky='w')
            invalid_count += 1
        elif utils.invalid_name(name) == 1:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=1, sticky='w')
            invalid_count += 1
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')

        # Validate gender
        if len(gend) == 0:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
            Label(entry_frame, fg='crimson', text='Gender cannot be empty!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=2, sticky='w')
            invalid_count += 1
        elif utils.invalid_gend(gend) == 1:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=2, sticky='w')
            invalid_count += 1
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')

        # Validate birthday
        if len(dob) == 0:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
            Label(entry_frame, fg='crimson', text='Birthday cannot be empty!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=3, sticky='w')
            invalid_count += 1
        elif utils.invalid_dob(dob) == 1:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=3, sticky='w')
            invalid_count += 1
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')

        # Validate phone:
        if len(phone) != 0 and phone != '_':
            if utils.invalid_phone(phone) == 1:
                Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
                    .grid(column=6, row=4, sticky='w')
                invalid_count += 1
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=4, sticky='w')

        # Validate email
        if len(email) != 0 and email != '_':
            if utils.invalid_email(email) == 1:
                Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')). \
                    grid(column=6, row=5, sticky='w')
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=5, sticky='w')

        # Validate salary
        if len(salary) == 0:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
            Label(entry_frame, fg='crimson', text='Salary cannot be empty!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=6, sticky='w')
            invalid_count += 1
        elif utils.invalid_salary(salary) == 1:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=6, sticky='w')
            invalid_count += 1

        # If All Valid
        if invalid_count == 0:
            emp_id = emp_tree.item(selected_employee, 'values')[0]
            for employee in employee_list:
                if employee.get_id() == emp_id:
                    employee.set_id(id)
                    employee.set_name(name)
                    employee.set_gend(gend)
                    employee.set_dob(dob)
                    employee.set_salary(salary)
                    if len(phone) > 0:
                        employee.set_phone(phone)
                    elif len(phone) == 0:
                        employee.set_phone('_')
                    if len(email) > 0:
                        employee.set_email(email)
                    elif len(email) == 0:
                        employee.set_email('_')
                    break

            emp_tree.item(selected_employee, text="", values=(id, name, gend, dob, salary))
            selected_employee = -1

            id_entry.delete(0, END)
            name_entry.delete(0, END)
            gend_entry.delete(0, END)
            dob_entry.delete(0, END)
            phone_entry.delete(0, END)
            email_entry.delete(0, END)
            salary_entry.delete(0, END)

            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=4, sticky='w')
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=5, sticky='w')
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=6, sticky='w')


def emp_press(window, width, height, employee_list):
    global selected_employee
    selected_employee = -1

    emp_win = Toplevel(window)
    emp_win.geometry("%dx%d" % (width, height))
    emp_win.title("Employee Information Management")
    Frame(emp_win, ).place(x=0, y=0, width=width / 2, height=height)

    style = ttk.Style()
    style.theme_use('clam')
    style.configure("Treeview", background="silver", foreground="black", rowheight=25, font=("Inter", 12),
                    fieldbackground="silver")
    style.configure("Treeview.Heading", font=("Inter", 16, 'bold'))
    style.map('Treeview', background=[('selected', 'dark blue')])

    # Create TreeView List
    emp_tree = ttk.Treeview(emp_win, selectmode='browse', show='headings')

    # Define columns
    emp_tree['columns'] = ("ID", "Name", "Gender", "Date of Birth", "Salary")

    # Format columns
    emp_tree.column("#0", width=0, stretch=NO)
    emp_tree.column("ID", anchor='center', width=75)
    emp_tree.column("Name", anchor='w', width=150)
    emp_tree.column("Gender", anchor='center', width=75)
    emp_tree.column("Date of Birth", anchor='center', width=125)
    emp_tree.column("Salary", anchor='center', width=75)

    # Create Headings
    emp_tree.heading("#0", text="")
    emp_tree.heading("ID", text="ID", anchor='center',
                     command=lambda: utils.sort_employee_by_column(emp_tree, employee_list, "ID", False))
    emp_tree.heading("Name", text="Name", anchor='center',
                     command=lambda: utils.sort_employee_by_column(emp_tree, employee_list, "Name", False))
    emp_tree.heading("Gender", text="Gender", anchor='center',
                     command=lambda: utils.sort_employee_by_column(emp_tree, employee_list, "Gender", False))
    emp_tree.heading("Date of Birth", text="Date of Birth", anchor='center',
                     command=lambda: utils.sort_employee_by_column(emp_tree, employee_list, "Date of Birth", False))
    emp_tree.heading("Salary", text="Salary", anchor='center',
                     command=lambda: utils.sort_employee_by_column(emp_tree, employee_list, "Salary", False))

    emp_tree.bind('<Motion>', 'break')

    # Insert Data
    for employee in employee_list:
        emp_tree.insert(parent='', index='end', text='', iid=employee.get_id(),
                        values=(
                            employee.get_id(), employee.get_name(), employee.get_gend(),
                            employee.get_dob(), employee.get_salary()))

    emp_tree.place(x=width / 2 + 50, y=50, height=height - 250, width=width / 2 - 100)

    # =========================================================================================

    Label(emp_win, fg='black', text='EMPLOYEES MANAGEMENT', font=("Inter", 20, 'bold')).place(
        x=50, y=25, width=width / 2 - 100, height=50)
    Frame(emp_win, bg='crimson').place(x=50, y=85, width=width / 2 - 100, height=2)
    entry_frame = Frame(emp_win, )
    entry_frame.place(x=50, y=100, width=width / 2 - 100, height=height / 2)

    Frame(emp_win, bg='crimson').place(x=50, y=350, width=width / 2 - 100, height=2)

    Label(emp_win, text=' - Entries marked with " * " must not be empty ',
          anchor='w', fg='black', font=("Inter", 12, 'bold')) \
        .place(x=50, y=360, height=30)
    Label(emp_win, text=' - Gender must be " M " or " F " ',
          anchor='w', fg='black', font=("Inter", 12, 'bold')) \
        .place(x=50, y=385, height=30)
    Label(emp_win, text=' - Date of Birth must be " dd/mm/yyyy " ',
          anchor='w', fg='black', font=("Inter", 12, 'bold')) \
        .place(x=50, y=410, height=30)
    Label(emp_win, text=' - Phone & Salary must be numbers ',
          anchor='w', fg='black', font=("Inter", 12, 'bold')) \
        .place(x=50, y=435, height=30)

    # Column 0: ( * )
    Label(entry_frame, fg='red', text='( * )', font=("Inter", 14, 'bold')).grid(column=0, row=0)
    Label(entry_frame, fg='red', text='( * )', font=("Inter", 14, 'bold')).grid(column=0, row=1)
    Label(entry_frame, fg='red', text='( * )', font=("Inter", 14, 'bold')).grid(column=0, row=2)
    Label(entry_frame, fg='red', text='( * )', font=("Inter", 14, 'bold')).grid(column=0, row=3)
    Label(entry_frame, fg='red', text='( * )', font=("Inter", 14, 'bold')).grid(column=0, row=6)

    # Column 1: |
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=0)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=1)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=2)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=3)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=4)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=5)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=6)

    # Column 2: Attribute
    Label(entry_frame, fg='black', text=' - ID - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=0)
    Label(entry_frame, fg='black', text=' - Name - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=1)
    Label(entry_frame, fg='black', text=' - Gender - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=2)
    Label(entry_frame, fg='black', text=' - DoB - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=3)
    Label(entry_frame, fg='black', text=' - Phone - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=4)
    Label(entry_frame, fg='black', text=' - Email - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=5)
    Label(entry_frame, fg='black', text=' - Salary - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=6)

    # Column 3: |
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=0)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=1)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=2)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=3)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=4)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=5)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=6)

    # Column 4: Entries
    id_entry = Entry(entry_frame)
    id_entry.grid(column=4, row=0)

    name_entry = Entry(entry_frame)
    name_entry.grid(column=4, row=1)

    gend_entry = Entry(entry_frame)
    gend_entry.grid(column=4, row=2)

    dob_entry = Entry(entry_frame)
    dob_entry.grid(column=4, row=3)

    phone_entry = Entry(entry_frame)
    phone_entry.grid(column=4, row=4)

    email_entry = Entry(entry_frame)
    email_entry.grid(column=4, row=5)

    salary_entry = Entry(entry_frame)
    salary_entry.grid(column=4, row=6)

    # Column 5: |
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=0)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=1)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=2)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=3)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=4)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=5)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=6)

    # ==============================================================================

    # Buttons
    emp_win.create_but = PhotoImage(file="images/Create_button.png")
    emp_win.update_but = PhotoImage(file="images/Update_button.png")
    emp_win.clear_but = PhotoImage(file="images/Clear_button.png")
    emp_win.remove_but = PhotoImage(file="images/Remove_button.png")
    emp_win.empty_but = PhotoImage(file="images/Empty_button.png")

    add_employee_button = Button(emp_win, image=emp_win.create_but, borderwidth=0,
                                 command=lambda: create_employee(employee_list, emp_tree, entry_frame,
                                                                 id_entry, name_entry, gend_entry, dob_entry,
                                                                 phone_entry, email_entry, salary_entry))
    add_employee_button.place(x=50, y=height - 160)

    update_employee_button = Button(emp_win, image=emp_win.update_but, borderwidth=0,
                                    command=lambda: update_employee(employee_list, emp_tree, entry_frame,
                                                                    id_entry, name_entry, gend_entry, dob_entry,
                                                                    phone_entry, email_entry, salary_entry))
    update_employee_button.place(x=50 + 400, y=height - 160)

    clear_button = Button(emp_win, image=emp_win.clear_but, borderwidth=0,
                          command=lambda: clear_entry(entry_frame, id_entry, name_entry, gend_entry, dob_entry,
                                                      phone_entry, email_entry, salary_entry))
    clear_button.place(x=50 + 400 + 400, y=height - 160)

    remove_employee_button = Button(emp_win, image=emp_win.remove_but, borderwidth=0,
                                    command=lambda: remove_employee(employee_list, emp_tree))
    remove_employee_button.place(x=50 + 400 + 400 + 400, y=height - 160)

    remove_all_employee_button = Button(emp_win, image=emp_win.empty_but, borderwidth=0,
                                        command=lambda: remove_all_employees(employee_list, emp_tree))
    remove_all_employee_button.place(x=50 + 400 + 400 + 400 + 400, y=height - 160)
