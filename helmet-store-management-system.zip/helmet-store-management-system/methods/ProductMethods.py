from domains.Products import *
import methods.UtilityMethods as utils
from tkinter import *
from tkinter import ttk
from PIL import ImageTk, Image

global selected_product


# Empty entry boxes and delete warnings
def clear_entry(entry_frame, id_entry, name_entry, price_entry, stock_entry):
    # Delete all warnings
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')

    # Empty entry boxes
    id_entry.delete(0, END)
    name_entry.delete(0, END)
    price_entry.delete(0, END)
    stock_entry.delete(0, END)

    # Set selected_product to -1
    global selected_product
    selected_product = -1


# Create a new customer
def create_product(product_list, prod_tree, entry_frame, id_entry, name_entry, price_entry, stock_entry):
    # Create labels
    Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
        column=6, row=0, sticky='w')
    Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
        column=6, row=1, sticky='w')
    Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
        column=6, row=2, sticky='w')

    global product_id
    id = id_entry.get()
    name = name_entry.get()
    price = price_entry.get()
    stock = stock_entry.get()

    # Count the amount of invalid entries
    invalid_count = 0

    # Validate ID
    if len(id) == 0:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
        Label(entry_frame, fg='crimson', text='ID cannot be empty!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=0, sticky='w')
        invalid_count += 1
    elif utils.invalid_id(id, "P-") == 1:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
        Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=0, sticky='w')
        invalid_count += 1
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')

    # Validate name
    if len(name) == 0:
        Label(entry_frame, fg='crimson', text='Name cannot be empty!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=1, sticky='w')
        invalid_count += 1
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')

    # Validate price
    if len(price) == 0:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
        Label(entry_frame, fg='crimson', text='Price cannot be empty!',
              font=("Ariel", 14, 'bold')) \
            .grid(column=6, row=2, sticky='w')
        invalid_count += 1
    elif utils.invalid_price(price) == 1:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
        Label(entry_frame, fg='crimson', text='Invalid input!', font=("Ariel", 14, 'bold')) \
            .grid(column=6, row=2, sticky='w')
        invalid_count += 1
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')

    # Validate stock
    if len(stock) == 0:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
        Label(entry_frame, fg='crimson', text='Stock cannot be empty!',
              font=("Ariel", 14, 'bold')) \
            .grid(column=6, row=3, sticky='w')
        invalid_count += 1
    elif utils.invalid_stock(int(stock)):
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
        Label(entry_frame, fg='crimson', text='Invalid input!', font=("Ariel", 14, 'bold')) \
            .grid(column=6, row=3, sticky='w')
        invalid_count += 1
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')

    # If everything is valid
    if invalid_count == 0:
        new_prod = Products(id, name, price, stock)
        product_list.append(new_prod)

        # Display on treeview
        prod_tree.insert(parent='', index='end', text='', iid=id,
                         values=(id, name, price, stock))

        # Empty entry boxes
        id_entry.delete(0, END)
        name_entry.delete(0, END)
        price_entry.delete(0, END)
        stock_entry.delete(0, END)

        # Delete all Warnings
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')


# Remove a selected product
def remove_product(products_list, prod_tree):
    # If a product is selected
    if len(prod_tree.selection()) > 0:
        # Get that product id
        selected_prod = prod_tree.selection()[0]
        prod_id = prod_tree.item(selected_prod, 'values')[0]

        # Search for that product in the list and delete
        for product in products_list:
            if product.get_id() == prod_id:
                products_list.remove(product)
                break

        # Delete that product from the treeview
        prod_tree.delete(selected_prod)


# Remove all products
def remove_all_products(product_list, prod_tree):
    for product in prod_tree.get_children():
        prod_tree.delete(product)
    product_list.clear()


# Update a product's info
def update_product(product_list, prod_tree, entry_frame, id_entry, name_entry, price_entry, stock_entry):
    global selected_product
    global prod_id

    selected_product = prod_tree.selection()[0]
    prod_id = prod_tree.item(selected_product, 'values')[0]

    if selected_product != -1:
        # Delete all Warnings
        Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=0, sticky='w')
        Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=1, sticky='w')
        Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=2, sticky='w')
        Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=3, sticky='w')

        # Read Inputs
        id = id_entry.get()
        name = name_entry.get()
        price = price_entry.get()
        stock = stock_entry.get()

        # Validation
        invalid_count = 0

        # Validate ID
        if len(id) == 0:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
            Label(entry_frame, fg='crimson', text='ID cannot be empty!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=0, sticky='w')
            invalid_count += 1
        elif utils.invalid_id(id, "P-") == 1:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=0, sticky='w')
            invalid_count += 1
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')

        # Validate name
        if len(name) == 0:
            Label(entry_frame, fg='crimson', text='Name cannot be empty!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=1, sticky='w')
            invalid_count += 1
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')

        # Validate price
        if len(price) == 0:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
            Label(entry_frame, fg='crimson', text='Price cannot be empty!',
                  font=("Ariel", 14, 'bold')) \
                .grid(column=6, row=2, sticky='w')
            invalid_count += 1
        elif utils.invalid_price(price) == 1:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Ariel", 14, 'bold')) \
                .grid(column=6, row=2, sticky='w')
            invalid_count += 1
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')

        # Validate stock
        if len(stock) == 0:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
            Label(entry_frame, fg='crimson', text='Stock cannot be empty!',
                  font=("Ariel", 14, 'bold')) \
                .grid(column=6, row=3, sticky='w')
            invalid_count += 1
        elif utils.invalid_stock(int(stock)):
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Ariel", 14, 'bold')) \
                .grid(column=6, row=3, sticky='w')
            invalid_count += 1
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')

        # If ALL Valid
        if invalid_count == 0:
            prod_id = prod_tree.item(selected_product, 'values')[0]
            for product in product_list:
                if product.get_id() == prod_id:
                    product.set_id(id)
                    product.set_name(name)
                    product.set_price(price)
                    product.set_stock(stock)

            prod_tree.item(selected_product, text="", values=(id, name, price, stock))
            selected_product = -1

            # Empty entry boxes
            id_entry.delete(0, END)
            name_entry.delete(0, END)
            price_entry.delete(0, END)
            stock_entry.delete(0, END)

            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')


def prod_press(window, width, height, product_list):
    global selected_product
    global product_id

    selected_product = -1

    prod_win = Toplevel(window)
    prod_win.geometry("%dx%d" % (width, height))
    prod_win.title("Product Information Management")
    Frame(prod_win, ).place(x=0, y=0, width=width / 2, height=height)

    style = ttk.Style()
    style.theme_use('clam')
    style.configure("Treeview", background="silver", foreground="black", rowheight=25, font=("Inter", 12),
                    fieldbackground="silver")
    style.configure("Treeview.Heading", font=("Inter", 16, 'bold'))
    style.map('Treeview', background=[('selected', 'dark blue')])

    # Create TreeView List
    prod_tree = ttk.Treeview(prod_win, selectmode='browse', show='headings')

    # Define columns
    prod_tree['columns'] = ("ID", "Name", "Price", "Stock")

    # Format columns
    prod_tree.column("#0", width=0, stretch=NO)
    prod_tree.column("ID", anchor='center', width=75)
    prod_tree.column("Name", anchor='w', width=150)
    prod_tree.column("Price", anchor='center', width=75)
    prod_tree.column("Stock", anchor='center', width=125)

    # Create Headings
    prod_tree.heading("#0", text="")
    prod_tree.heading("ID", text="ID", anchor='center',
                      command=lambda: utils.sort_product_by_column(prod_tree, product_list, "ID", False))
    prod_tree.heading("Name", text="Name", anchor='center',
                      command=lambda: utils.sort_product_by_column(prod_tree, product_list, "Name", False))
    prod_tree.heading("Price", text="Price", anchor='center',
                      command=lambda: utils.sort_product_by_column(prod_tree, product_list, "Price", False))
    prod_tree.heading("Stock", text="Stock", anchor='center',
                      command=lambda: utils.sort_product_by_column(prod_tree, product_list, "Stock", False))

    prod_tree.bind('<Motion>', 'break')

    # Insert Data
    for product in product_list:
        prod_tree.insert(parent='', index='end', text='',
                         values=(
                             product.get_id(), product.get_name(), product.get_price(), product.get_stock()))

    prod_tree.place(x=width / 2 + 50, y=50, height=height - 250, width=width / 2 - 100)

    # =========================================================================================

    Label(prod_win, fg='black', text='PRODUCTS MANAGEMENT', font=("Inter", 20, 'bold')).place(
        x=50, y=25, width=width / 2 - 100, height=50)
    Frame(prod_win, bg='crimson').place(x=50, y=85, width=width / 2 - 100, height=2)
    entry_frame = Frame(prod_win, )
    entry_frame.place(x=50, y=100, width=width / 2 - 100, height=height / 2)

    Frame(prod_win, bg='crimson').place(x=50, y=350, width=width / 2 - 100, height=2)

    Label(prod_win, text=' - Entries marked with " * " must not be empty ',
          anchor='w', fg='black', font=("Inter", 12, 'bold')) \
        .place(x=50, y=360, height=30)
    Label(prod_win, text=' - Price must be larger than 0 ',
          anchor='w', fg='black', font=("Inter", 12, 'bold')) \
        .place(x=50, y=385, height=30)

    # Column 0: ( * )
    Label(entry_frame, fg='red', text='( * )', font=("Inter", 14, 'bold')).grid(column=0, row=0)
    Label(entry_frame, fg='red', text='( * )', font=("Inter", 14, 'bold')).grid(column=0, row=1)
    Label(entry_frame, fg='red', text='( * )', font=("Inter", 14, 'bold')).grid(column=0, row=2)
    Label(entry_frame, fg='red', text='( * )', font=("Inter", 14, 'bold')).grid(column=0, row=3)

    # Column 1: |
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=0)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=1)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=2)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=3)

    # Column 2: Attribute
    Label(entry_frame, fg='black', text=' - ID - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=0)
    Label(entry_frame, fg='black', text=' - Name - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=1)
    Label(entry_frame, fg='black', text=' - Price - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=2)
    Label(entry_frame, fg='black', text=' - Stock - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=3)

    # Column 3: |
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=0)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=1)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=2)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=3)

    # Column 4: Entries
    id_entry = Entry(entry_frame)
    id_entry.grid(column=4, row=0)

    name_entry = Entry(entry_frame)
    name_entry.grid(column=4, row=1)

    price_entry = Entry(entry_frame)
    price_entry.grid(column=4, row=2)

    stock_entry = Entry(entry_frame)
    stock_entry.grid(column=4, row=3)

    # Column 5: |
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=0)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=1)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=2)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=3)

    # ==============================================================================

    # Buttons
    prod_win.create_but = PhotoImage(file="images/Create_button.png")
    prod_win.update_but = PhotoImage(file="images/Update_button.png")
    prod_win.clear_but = PhotoImage(file="images/Clear_button.png")
    prod_win.remove_but = PhotoImage(file="images/Remove_button.png")
    prod_win.empty_but = PhotoImage(file="images/Empty_button.png")

    add_product_button = Button(prod_win, image=prod_win.create_but, borderwidth=0,
                                command=lambda: create_product(product_list, prod_tree, entry_frame,
                                                               id_entry, name_entry, price_entry, stock_entry))
    add_product_button.place(x=50, y=height - 160)

    update_product_button = Button(prod_win, image=prod_win.update_but, borderwidth=0,
                                   command=lambda: update_product(product_list, prod_tree, entry_frame,
                                                                  id_entry, name_entry, price_entry, stock_entry))
    update_product_button.place(x=50 + 400, y=height - 160)

    clear_button = Button(prod_win, image=prod_win.clear_but, borderwidth=0,
                          command=lambda: clear_entry(entry_frame, id_entry, name_entry, price_entry, stock_entry))
    clear_button.place(x=50 + 400 + 400, y=height - 160)

    remove_product_button = Button(prod_win, image=prod_win.remove_but, borderwidth=0,
                                   command=lambda: remove_product(product_list, prod_tree))
    remove_product_button.place(x=50 + 400 + 400 + 400, y=height - 160)

    remove_all_product_button = Button(prod_win, image=prod_win.empty_but, borderwidth=0,
                                       command=lambda: remove_all_products(product_list, prod_tree))
    remove_all_product_button.place(x=50 + 400 + 400 + 400 + 400, y=height - 160)
