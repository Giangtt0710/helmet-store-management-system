from domains.People import *
import methods.UtilityMethods as utils
from tkinter import *
from tkinter import ttk
from PIL import ImageTk, Image

global selected_customer


# Empty entry boxes and delete warnings
def clear_entry(entry_frame, id_entry, name_entry, gend_entry, dob_entry, phone_entry, email_entry):
    # Delete all warnings
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=4, sticky='w')
    Label(entry_frame, fg='crimson', text='                                                            ',
          font=("Inter", 14, 'bold')).grid(column=6, row=5, sticky='w')

    # Empty entry boxes
    id_entry.delete(0, END)
    name_entry.delete(0, END)
    gend_entry.delete(0, END)
    dob_entry.delete(0, END)
    phone_entry.delete(0, END)
    email_entry.delete(0, END)

    # Set selected_customer to -1
    global selected_customer
    selected_customer = -1


# Create a new customer
def create_customer(customer_list, cus_tree, entry_frame, id_entry, name_entry, gend_entry, dob_entry,
                    phone_entry, email_entry):
    # Create labels
    Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
        column=6, row=0, sticky='w')
    Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
        column=6, row=1, sticky='w')
    Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
        column=6, row=2, sticky='w')
    Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
        column=6, row=3, sticky='w')
    Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
        column=6, row=4, sticky='w')

    id = id_entry.get()
    name = name_entry.get()
    gend = gend_entry.get()
    dob = dob_entry.get()
    phone = phone_entry.get()
    email = email_entry.get()

    # Count the amount of invalid entries
    invalid_count = 0

    # Validate ID
    if len(id) == 0:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
        Label(entry_frame, fg='crimson', text='ID cannot be empty!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=0, sticky='w')
        invalid_count += 1
    elif utils.invalid_id(id, "C-") == 1:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
        Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=0, sticky='w')
        invalid_count += 1
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')

    # Validate name
    if len(name) == 0:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
        Label(entry_frame, fg='crimson', text='Name cannot be empty!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=1, sticky='w')
        invalid_count += 1
    elif utils.invalid_name(name) == 1:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
        Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=1, sticky='w')
        invalid_count += 1
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')

    # Validate gender
    if len(gend) == 0:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
        Label(entry_frame, fg='crimson', text='Gender cannot be empty!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=2, sticky='w')
        invalid_count += 1
    elif utils.invalid_gend(gend) == 1:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
        Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=2, sticky='w')
        invalid_count += 1
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')

    # Validate birthday
    if len(dob) == 0:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
        Label(entry_frame, fg='crimson', text='Birthday cannot be empty!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=3, sticky='w')
        invalid_count += 1
    elif utils.invalid_dob(dob) == 1:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
        Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
            .grid(column=6, row=3, sticky='w')
        invalid_count += 1
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')

    # Validate phone:
    if len(phone) != 0 and phone != '_':
        if utils.invalid_phone(phone) == 1:
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=4, sticky='w')
            invalid_count += 1
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=4, sticky='w')

    # Validate email
    if len(email) != 0 and email != '_':
        if utils.invalid_email(email) == 1:
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')). \
                grid(column=6, row=5, sticky='w')
    else:
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=5, sticky='w')

    # If everything is valid
    if invalid_count == 0:
        # Add to customer list
        new_cus = Customer(id, name, gend, dob)
        customer_list.append(new_cus)

        # Display on treeview
        cus_tree.insert(parent='', index='end', text='', iid=id, values=(id, name, gend, dob))

        # Empty entry boxes
        id_entry.delete(0, END)
        name_entry.delete(0, END)
        gend_entry.delete(0, END)
        dob_entry.delete(0, END)
        phone_entry.delete(0, END)
        email_entry.delete(0, END)

        # Delete all warnings
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=4, sticky='w')
        Label(entry_frame, fg='crimson', text='                                                            ',
              font=("Inter", 14, 'bold')).grid(column=6, row=5, sticky='w')


# Remove a selected customer
def remove_customer(customers_list, cus_tree):
    # If a customer is selected
    if len(cus_tree.selection()) > 0:
        # Get that customer id
        selected_cus = cus_tree.selection()[0]
        cus_id = cus_tree.item(selected_cus, 'values')[0]

        # Search for that customer in the list and delete
        for customer in customers_list:
            if customer.get_id() == cus_id:
                customers_list.remove(customer)
                break

        # Delete that customer from the treeview
        cus_tree.delete(selected_cus)


# Remove all customers
def remove_all_customers(customer_list, cus_tree):
    for customer in cus_tree.get_children():
        cus_tree.delete(customer)
    customer_list.clear()


# Update a customer's info
def update_customer(customer_list, cus_tree, entry_frame, id_entry, name_entry, gend_entry, dob_entry,
                    phone_entry, email_entry):
    global selected_customer
    global cus_id
    global cus_name
    global cus_gend
    global cus_dob

    selected_customer = cus_tree.selection()[0]
    # If a customer is selected, create labels for warning
    if selected_customer != -1:
        Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=0, sticky='w')
        Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=1, sticky='w')
        Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=2, sticky='w')
        Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=3, sticky='w')
        Label(entry_frame, fg='crimson', text='', font=("Inter", 14, 'bold')).grid(
            column=6, row=4, sticky='w')

        id = id_entry.get()
        name = name_entry.get()
        gend = gend_entry.get()
        dob = dob_entry.get()
        phone = phone_entry.get()
        email = email_entry.get()

        # Count invalid entries
        invalid_count = 0

        # Validate ID
        if len(id) == 0:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
            Label(entry_frame, fg='crimson', text='ID cannot be empty!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=0, sticky='w')
            invalid_count += 1
        elif utils.invalid_id(id, "C-") == 1:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=0, sticky='w')
            invalid_count += 1
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')

        # Validate name
        if len(name) == 0:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
            Label(entry_frame, fg='crimson', text='Name cannot be empty!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=1, sticky='w')
            invalid_count += 1
        elif utils.invalid_name(name) == 1:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=1, sticky='w')
            invalid_count += 1
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')

        # Validate gender
        if len(gend) == 0:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
            Label(entry_frame, fg='crimson', text='Gender cannot be empty!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=2, sticky='w')
            invalid_count += 1
        elif utils.invalid_gend(gend) == 1:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=2, sticky='w')
            invalid_count += 1
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')

        # Validate birthday
        if len(dob) == 0:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
            Label(entry_frame, fg='crimson', text='Birthday cannot be empty!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=3, sticky='w')
            invalid_count += 1
        elif utils.invalid_dob(dob) == 1:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
            Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
                .grid(column=6, row=3, sticky='w')
            invalid_count += 1
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')

        # Validate phone:
        if len(phone) != 0 and phone != '_':
            if utils.invalid_phone(phone) == 1:
                Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')) \
                    .grid(column=6, row=4, sticky='w')
                invalid_count += 1
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=4, sticky='w')

        # Validate email
        if len(email) != 0 and email != '_':
            if utils.invalid_email(email) == 1:
                Label(entry_frame, fg='crimson', text='Invalid input!', font=("Inter", 14, 'bold')). \
                    grid(column=6, row=5, sticky='w')
        else:
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=5, sticky='w')

        # If all entries are valid
        if invalid_count == 0:
            cus_id = cus_tree.item(selected_customer, 'values')[0]
            for customer in customer_list:
                if customer.get_id() == cus_id:
                    # Update customer list info
                    customer.set_id(id)
                    customer.set_name(name)
                    customer.set_gend(gend)
                    customer.set_dob(dob)
                    if len(phone) > 0:
                        customer.set_phone(phone)
                    elif len(phone) == 0:
                        customer.set_phone('_')
                    if len(email) > 0:
                        customer.set_email(email)
                    elif len(email) == 0:
                        customer.set_email('_')
                    break

            cus_tree.item(selected_customer, text="", values=(id, name, gend, dob))
            selected_customer = -1

            # Empty entry boxes
            id_entry.delete(0, END)
            name_entry.delete(0, END)
            gend_entry.delete(0, END)
            dob_entry.delete(0, END)
            phone_entry.delete(0, END)
            email_entry.delete(0, END)

            # Delete all warnings
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=0, sticky='w')
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=1, sticky='w')
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=2, sticky='w')
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=3, sticky='w')
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=4, sticky='w')
            Label(entry_frame, fg='crimson', text='                                                            ',
                  font=("Inter", 14, 'bold')).grid(column=6, row=5, sticky='w')


# Create a window and put that on top of the main window
def cus_press(window, width, height, customer_list):
    global selected_customer

    selected_customer = -1

    # Create window with title and push to top
    cus_win = Toplevel(window)
    cus_win.geometry("%dx%d" % (width, height))
    cus_win.title("Customer Information Management")
    Frame(cus_win).place(x=0, y=0, width=width / 2, height=height)

    # Config ttk style
    style = ttk.Style()
    style.theme_use('clam')
    style.configure("Treeview", background="silver", foreground="black", rowheight=25, font=("Inter", 12),
                    fieldbackground="silver")
    style.configure("Treeview.Heading", font=("Inter", 16, 'bold'))
    style.map('Treeview', background=[('selected', 'dark blue')])

    # Create treeview of list
    cus_tree = ttk.Treeview(cus_win, selectmode='browse', show='headings')

    # Define columns
    cus_tree['columns'] = ("ID", "Name", "Gender", "Date of Birth")

    # Format columns
    cus_tree.column("#0", width=0, stretch=NO)
    cus_tree.column("ID", anchor='center', width=75)
    cus_tree.column("Name", anchor='w', width=150)
    cus_tree.column("Gender", anchor='center', width=75)
    cus_tree.column("Date of Birth", anchor='center', width=125)

    # Create headings
    cus_tree.heading("#0", text="")
    cus_tree.heading("ID", text="ID", anchor='center',
                     command=lambda: utils.sort_customer_by_column(cus_tree, customer_list, "ID", False))
    cus_tree.heading("Name", text="Name", anchor='center',
                     command=lambda: utils.sort_customer_by_column(cus_tree, customer_list, "Name", False))
    cus_tree.heading("Gender", text="Gender", anchor='center',
                     command=lambda: utils.sort_customer_by_column(cus_tree, customer_list, "Gender", False))
    cus_tree.heading("Date of Birth", text="Date of Birth", anchor='center',
                     command=lambda: utils.sort_customer_by_column( cus_tree, customer_list, "Date of Birth", False))

    cus_tree.bind('<Motion>', 'break')

    # Insert customer from list to treeview
    for customer in customer_list:
        cus_tree.insert(parent='', index='end', text='', iid=customer.get_id(),
                        values=(
                            customer.get_id(), customer.get_name(), customer.get_gend(), customer.get_dob()))

    cus_tree.place(x=width / 2 + 50, y=50, height=height - 250, width=width / 2 - 100)

    # =========================================================================================

    # Create labels for the window
    Label(cus_win, fg='black', text='CUSTOMERS MANAGEMENT', font=("Inter", 20, 'bold')).place(
        x=50, y=25, width=width / 2 - 100, height=50)
    Frame(cus_win, bg='crimson').place(x=50, y=85, width=width / 2 - 100, height=2)
    entry_frame = Frame(cus_win)
    entry_frame.place(x=50, y=100, width=width / 2 - 100, height=height / 2)

    Frame(cus_win, bg='crimson').place(x=50, y=350, width=width / 2 - 100, height=2)

    # Entries to output rules for the input
    Label(cus_win, text=' - Entries marked with " * " must not be empty ',
          anchor='w', fg='black', font=("Inter", 12, 'bold')) \
        .place(x=50, y=360, height=30)
    Label(cus_win, text=' - Gender must be " M " or " F " ',
          anchor='w', fg='black', font=("Inter", 12, 'bold')) \
        .place(x=50, y=385, height=30)
    Label(cus_win, text=' - Date of Birth must be " dd/mm/yyyy " ',
          anchor='w', fg='black', font=("Inter", 12, 'bold')) \
        .place(x=50, y=410, height=30)
    Label(cus_win, text=' - Phone must be numbers ',
          anchor='w', fg='black', font=("Inter", 12, 'bold')) \
        .place(x=50, y=435, height=30)

    # Column 0: ( * )
    Label(entry_frame, fg='red', text='( * )', font=("Inter", 14, 'bold')).grid(column=0, row=0)
    Label(entry_frame, fg='red', text='( * )', font=("Inter", 14, 'bold')).grid(column=0, row=1)
    Label(entry_frame, fg='red', text='( * )', font=("Inter", 14, 'bold')).grid(column=0, row=2)
    Label(entry_frame, fg='red', text='( * )', font=("Inter", 14, 'bold')).grid(column=0, row=3)

    # Column 1: |
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=0)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=1)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=2)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=3)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=4)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=1, row=5)

    # Column 2: Attribute
    Label(entry_frame, fg='black', text=' - ID - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=0)
    Label(entry_frame, fg='black', text=' - Name - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=1)
    Label(entry_frame, fg='black', text=' - Gender - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=2)
    Label(entry_frame, fg='black', text=' - DoB - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=3)
    Label(entry_frame, fg='black', text=' - Phone - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=4)
    Label(entry_frame, fg='black', text=' - Email - ', font=("Inter", 14, 'bold')) \
        .grid(column=2, row=5)

    # Column 3: |
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=0)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=1)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=2)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=3)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=4)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=3, row=5)

    # Column 4: Entries
    id_entry = Entry(entry_frame)
    id_entry.grid(column=4, row=0)

    name_entry = Entry(entry_frame)
    name_entry.grid(column=4, row=1)

    gend_entry = Entry(entry_frame)
    gend_entry.grid(column=4, row=2)

    dob_entry = Entry(entry_frame)
    dob_entry.grid(column=4, row=3)

    phone_entry = Entry(entry_frame)
    phone_entry.grid(column=4, row=4)

    email_entry = Entry(entry_frame)
    email_entry.grid(column=4, row=5)

    # Column 5: |
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=0)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=1)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=2)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=3)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=4)
    Label(entry_frame, fg='black', text=' | ', font=("Inter", 14, 'bold')).grid(column=5, row=5)

    # ==============================================================================

    # Buttons
    cus_win.create_but = PhotoImage(file="images/Create_button.png")
    cus_win.update_but = PhotoImage(file="images/Update_button.png")
    cus_win.clear_but = PhotoImage(file="images/Clear_button.png")
    cus_win.remove_but = PhotoImage(file="images/Remove_button.png")
    cus_win.empty_but = PhotoImage(file="images/Empty_button.png")

    add_customer_button = Button(cus_win, image=cus_win.create_but, borderwidth=0,
                                 command=lambda: create_customer(customer_list, cus_tree, entry_frame,
                                                                 id_entry, name_entry, gend_entry, dob_entry,
                                                                 phone_entry, email_entry))
    add_customer_button.place(x=50, y=height - 160)

    update_customer_button = Button(cus_win, image=cus_win.update_but, borderwidth=0,
                                    command=lambda: update_customer(customer_list, cus_tree, entry_frame,
                                                                    id_entry, name_entry, gend_entry, dob_entry,
                                                                    phone_entry, email_entry))
    update_customer_button.place(x=50 + 400, y=height - 160)

    clear_button = Button(cus_win, image=cus_win.clear_but, borderwidth=0,
                          command=lambda: clear_entry(entry_frame, id_entry, name_entry, gend_entry, dob_entry,
                                                      phone_entry, email_entry))
    clear_button.place(x=50 + 400 + 400, y=height - 160)

    remove_customer_button = Button(cus_win, image=cus_win.remove_but, borderwidth=0,
                                    command=lambda: remove_customer(customer_list, cus_tree))
    remove_customer_button.place(x=50 + 400 + 400 + 400, y=height - 160)

    remove_all_customer_button = Button(cus_win, image=cus_win.empty_but, borderwidth=0,
                                        command=lambda: remove_all_customers(customer_list, cus_tree))
    remove_all_customer_button.place(x=50 + 400 + 400 + 400 + 400, y=height - 160)
