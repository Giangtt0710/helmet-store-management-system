import datetime


def invalid_id(id, id_code: str):
    while True:
        try:
            if id[:2] != id_code or len(id) != 5:
                return 1
            else:
                return 0
        except ValueError:
            return 1


def invalid_name(name):
    while True:
        try:
            for i in range(len(name)):
                if name[i].isdigit():
                    return 1
            else:
                return 0
        except ValueError:
            return 1


def invalid_gend(gend):
    while True:
        try:
            if gend not in ('M', 'F', 'Male', 'Female'):
                return 1
            else:
                return 0
        except ValueError:
            return 1


def invalid_dob(dob):
    while True:
        try:
            day = int(dob[:2])
            month = int(dob[:5][-2:])
            s1 = dob[:3][-1:]
            s2 = dob[:6][-1:]
            if len(dob) != 10:
                return 1
            elif s1 != "/" or s2 != "/":
                return 1
            elif day < 1 or day > 31:
                return 1
            elif month < 1 or month > 12:
                return 1
            else:
                return 0
        except ValueError:
            return 1


def invalid_phone(phone):
    while True:
        try:
            for i in range(len(phone)):
                if not i.isdigit():
                    return 1
            return 0
        except ValueError:
            return 1


def invalid_email(email):
    while True:
        try:
            for i in range(len(email)):
                if email[i] == ' ':
                    return 1
            for i in range(len(email)):
                if email[i] == '@':
                    return 0
            return 1
        except ValueError:
            return 1


def invalid_salary(salary):
    while True:
        try:
            if int(salary) < 0:
                return 1
            else:
                return 0
        except ValueError:
            return 1


def invalid_price(price):
    while True:
        try:
            if int(price) < 0:
                return 1
            else:
                return 0
        except ValueError:
            return 1


def invalid_stock(stock: int):
    while True:
        try:
            if stock < 0:
                return 1
            else:
                return 0
        except ValueError:
            return 1


def sort_customer_by_column(treeview, arr, col, reverse):
    if col == "ID":
        arr.sort(key=lambda x: x.get_id(), reverse=reverse)
    if col == "Name":
        arr.sort(key=lambda x: x.get_name(), reverse=reverse)
    if col == "Gender":
        arr.sort(key=lambda x: x.get_gend(), reverse=reverse)
    if col == "Date of Birth":
        arr.sort(key=lambda x: datetime.datetime.strptime(x.get_dob(), '%d/%m/%Y'), reverse=reverse)
    # Delete all items and re-insert
    for i in treeview.get_children():
        treeview.delete(i)
    a_count = 0
    for element in arr:
        treeview.insert(parent='', index='end', iid=a_count, text='', values=(
            element.get_id(), element.get_name(), element.get_gend(), element.get_dob()))
        a_count += 1

    treeview.heading(col, text=col, command=lambda _col=col: sort_customer_by_column(treeview, arr, _col, not reverse))


def sort_employee_by_column(treeview, arr, col, reverse):
    if col == "ID":
        arr.sort(key=lambda x: x.get_id(), reverse=reverse)
    if col == "Name":
        arr.sort(key=lambda x: x.get_name(), reverse=reverse)
    if col == "Gender":
        arr.sort(key=lambda x: x.get_gend(), reverse=reverse)
    if col == "Date of Birth":
        arr.sort(key=lambda x: datetime.datetime.strptime(x.get_dob(), '%d/%m/%Y'), reverse=reverse)
    if col == "Salary":
        arr.sort(key=lambda x: x.get_salary(), reverse=reverse)
    # Delete all items and re-insert
    for i in treeview.get_children():
        treeview.delete(i)
    a_count = 0
    for element in arr:
        treeview.insert(parent='', index='end', iid=a_count, text='', values=(
            element.get_id(), element.get_name(), element.get_gend(), element.get_dob(), element.get_salary()))
        a_count += 1

    treeview.heading(col, text=col, command=lambda _col=col: sort_employee_by_column(treeview, arr, _col, not reverse))


def sort_product_by_column(treeview, arr, col, reverse):
    if col == "ID":
        arr.sort(key=lambda x: x.get_id(), reverse=reverse)
    if col == "Name":
        arr.sort(key=lambda x: x.get_name(), reverse=reverse)
    if col == "Price":
        arr.sort(key=lambda x: x.get_price(), reverse=reverse)
    if col == "Stock":
        arr.sort(key=lambda x: int(x.get_stock()), reverse=reverse)
    # Delete all items and re-insert
    for i in treeview.get_children():
        treeview.delete(i)
    a_count = 0
    for element in arr:
        treeview.insert(parent='', index='end', iid=a_count, text='', values=(
            element.get_id(), element.get_name(), element.get_price(), element.get_stock()))
        a_count += 1

    treeview.heading(col, text=col, command=lambda _col=col: sort_product_by_column(treeview, arr, _col, not reverse))
